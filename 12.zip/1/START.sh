clear;
node bot.js
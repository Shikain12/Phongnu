const { MessageEmbed } = require('discord.js');

module.exports = {
    name: 'admin',
    description: 'Admin Info',
    type: 'CHAT_INPUT',
    run: async (client, interaction) => {
        const embed = new MessageEmbed()
            .setTitle(`\`${client.user.username}'s admin\``)
            .setDescription(`\`\`\`ini\n[ 🔽 Name : Phan Văn Đợi]\n\`\`\`
                             \`\`\`ini\n[ 💍 Age : 2008 ]\n\`\`\`                                               
                             \`\`\`ini\n[ 📱 Phone : 0353863694 ]\n\`\`\`
                             \`\`\`ini\n[ 💒 City : Phan Rang]\n\`\`\`
                             \`\`\`ini\n[ 👉 Hobbies : xxxx]\n\`\`\`
                             \`\`\`ini\n[ 💚 Crush Name : Đếu Có ]\n\`\`\`
                             \`\`\`ini\n[ 🔗 Facebook  : ]\n\`\`\`
                             \`\`\`ini\n[ 📌 Github  : ]\n\`\`\`
                             \`\`\`ini\n[ 🎧 Music  : Air Remix ]\n\`\`\`



`)
            .setColor("RANDOM")
            .setFooter({ text: "© » Phan Văn Đợi" })
            .setTimestamp()
        interaction.reply({ embeds: [embed] });
    },
};